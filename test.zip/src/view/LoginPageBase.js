import React from "react";
import '../css/login.css'
import LoginStaticBackground from "../components/Login/LoginStaticBackground";
import Hellologin from "../asset/img/login/hello.png";

class LoginPageBase extends React.Component{

    render() {
        return (
            <div className="loginbase">
            </div>
        );
    }
}

export default LoginPageBase;